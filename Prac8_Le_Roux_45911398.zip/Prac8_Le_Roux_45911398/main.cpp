#include <iostream>
#include <iomanip>

using namespace std;

//Function to display data
void displayData(int*years, double*growthRates, int SIZE)
{
    // The title of the pop griwth output
    cout<<"Year "<<setw(30)<< "Population Growth Rate (%)"<<endl;

    for (int i = 0; i<SIZE; i++)
    {
       cout<<*(years+i)<<setw(30)<<*(growthRates+i)<<endl;
    }
}

// Function to calculate average
double Average(double*growthRates, int SIZE)
{
    double sum = 0.0;

    //for loop to iterate through
    for (int i = 0; i<SIZE; i++)
    {
        sum+= *(growthRates+i);
    }
    // returning the average
    return sum/10;

}

double Highest(double *growthRates, int SIZE)
{
    // assigning the highest to the value at the pointer
    double highest = *growthRates;

    //Iterating through all the elements in the array of growthRates
    for (int i = 0; i<SIZE; i++)
    {
        // If statement to check whether current value is larger than largest
       if (*(growthRates+i)> highest)
       {
           // assigning new largest to highest
           highest = *(growthRates+i);
       }
    }
    return highest;

}


int main()
{
    const int SIZE= 10;

    // Declaring array of population growth elements
    double popGrowthRate[SIZE] = {1.2, 1.5, 2.1, 2.3, 1.9, 2, 1.8, 1.6, 2.2, 2.5};

    // Declare years
    int years[SIZE] = {2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023};

    // declaration of pointers
    int  * yearPtr = years;
    double* popGrowthRatePtr = popGrowthRate;


    //Call display function
    displayData(yearPtr, popGrowthRatePtr, SIZE);

    //assigning avgGrowthRate to output of Average function
    double avgGrowthRate= Average(popGrowthRate, SIZE);
    cout<<"Average Population Growth Rate: "<< avgGrowthRate<<"%"<<endl;

    //assigning highestGrowthRate to output of Highest function
    double highestGrowthRate= Highest(popGrowthRate, SIZE);
    cout<<"Highest Population Growth Rate: "<< highestGrowthRate<<"%"<<endl;

    return 0;
}
