#include <iostream>
# include <iomanip>
#include <string>
# include <cmath>
using namespace std;

int main()
{
    // declaring variables
    int numEmployees, ID, salary, yearEmployed;
    string name, surname;

    // Variables for up to 3 employees
    int ID1=0, ID2=0, ID3=0, salary1=0, salary2=0,salary3=0, yearEmployed1=0,yearEmployed2=0, yearEmployed3=0;
    string name1,name2,name3, surname1,surname2,surname3;

    // Declaring totals
    int  totalID=0, totalYearsEmployed=0;
    double totalSalary = 0;

    do{
    //Prompting user to input number of employees
        cout << "Enter the number of employees (1 to 3): " ;
        cin>> numEmployees;

        // COndition to ensure number of employees is between 1 and 3
        if (numEmployees >= 1 && numEmployees<= 3){
            // For loop to ensure the loop runs the same amount of times as number of employees

            for( int i = 1; i <= numEmployees; i++){
                cout<<"Enter the details for employee "<< i<<":"<<endl;
                cout<<"Name: ";
                cin>>name;
                cout<<"Surname: ";
                cin>>surname;
                cout<<"ID: ";
                cin>>ID;
                cout<<"Salary: ";
                cin>>salary;
                cout<<"Year employed: ";
                cin>>yearEmployed;
                cout<< " "<< endl;

                // Saving variables according i
                //i = 1
                if (i==1){
                    name1 = name;
                    surname1 = surname;
                    ID1 = ID;
                    salary1 = salary;
                    yearEmployed1 = yearEmployed;
                    }
                // i = 2
                else if (i==2){
                    name2 = name;
                    surname2 = surname;
                    ID2 = ID;
                    salary2 = salary;
                    yearEmployed2 = yearEmployed;
                    }
                // i = 3
                else if (i==3){
                    name3 = name;
                    surname3 = surname;
                    ID3 = ID;
                    salary3 = salary;
                    yearEmployed3 = yearEmployed;
                    }

                // calculating totals
                totalSalary += salary;
                totalID += ID;
                totalYearsEmployed += yearEmployed;
            }
        // error handling for when user inputs invalid amount of IDs
        }else{
                cout<<"Number of employees must be between 1 and 3."<< endl;

        }
    }while(numEmployees <1 || numEmployees >3);

    //Printing table header
    cout<<left<<setw(15)<<"Name"<<setw(15)<<"Surname"<<setw(10)<<"ID"<<setw(10)<<"Salary"<<setw(15)<<"Year Employed"<< endl;
    cout << "-----------------------------------------------------------------------------" << endl;


      // Printing employee details
      //Employee 1
    for (int i = 1; i <= numEmployees; i++) {
            if (i ==1){
                cout<<left<<setw(15)<<name1<<setw(15)<<surname1<<setw(10)<<ID1<<setw(10)<<fixed<< setprecision(2)<<salary1<<setw(15)<<yearEmployed1<< endl;
            }
            //employee 2
            else if (i ==2){
                cout<<left<<setw(15)<<name2<<setw(15)<<surname2<<setw(10)<<ID2<<setw(10)<<fixed<< setprecision(2)<<salary2<<setw(15)<<yearEmployed2<< endl;
            }

             //employee 3
            else if (i ==3){
                cout<<left<<setw(15)<<name3<<setw(15)<<surname3<<setw(10)<<ID3<<setw(10)<<fixed<< setprecision(2)<<salary3<<setw(15)<<yearEmployed3<< endl;
            }

    }
    // Printing totoals
    cout<< " "<< endl;
    cout<<"Total Salary: " << fixed <<setprecision(2)<<totalSalary<<endl;
    cout<<"Total ID: " << totalID<<endl;
    cout<<"Total Years Employed: " <<totalYearsEmployed<<endl;

    return 0;
}
