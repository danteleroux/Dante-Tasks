#include <iostream>
#include <ctime>
#include <cstdlib>
#include <iomanip>

using namespace std;

//function to generate a random temperature for 7 days
void randomTemp(double temp[])
{
    // generating random number
    srand(time(0));

    // for loop to generate 7 random double values
    for (int i = 0; i < 7; i++){
        temp[i] = (rand() % 20 + 15) + static_cast<double>(rand()) / RAND_MAX;
    }
}

void displayTemps(double temp[])
{
    // Set the output to fixed point notation and 2 decimal places
     cout << fixed << setprecision(2);
    //Giving each day a temperature, by using a for loop
    for (int i = 0; i < 7; i++)
    {
        cout << "Day "<< i+1<<": "<< temp[i] << endl;
    }
    cout << endl;
}
int main()
{
    double temp[7];

    // Fill the array with random temperatures
    randomTemp(temp);

    // Output the temperatures
    cout << "Daily temperatures (in Celsius): " << endl;

    //calling display function
    displayTemps(temp);

    // Initializing the highest variable, equal to first variable of array
    double highest = temp[0];

    for (int j=0 ; j< 7; j++)
    {
        // Condition to check whether current value is more than the highest
        if(temp[j]> highest)
        {
             //if conditionis true, current value becomes highest
            highest = temp[j];
        }
    }
    // output of highest temperature
    cout<< "The highest temp is: "<< highest<< endl;

    // Initializing the lowest variable, equal to first variable of array
    double lowest = temp[0];
    //for loop to iterate through all the values of the array
    for (int k=0 ; k< 7; k++)
    {
        // Condition to check whether current value is less than the lowest
        if(temp[k] < lowest)
        {
            //if conditionis true, current value becomes lowest
            lowest = temp[k];
        }
    }
    // output of lowest temperature
     cout<< "The lowest temp is: "<< lowest<< endl;

    return 0;
}
