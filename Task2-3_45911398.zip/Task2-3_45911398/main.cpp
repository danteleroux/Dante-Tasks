#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    char choice;
    do {
        // Declaring grade variables
        int score;
        string feedback;
        char grade;

        cout << "Enter the student's score (0-100): ";
        cin >> score;

        // Input validation loop
        while (score < 0 || score > 100) {
            cout << "Invalid input. Please enter a number between 0 and 100: ";
            cin >> score;
        }

        // Finding grade and giving feedback
        if (score >= 90) {
            grade = 'A';
            feedback = "Excellent work!";
        } else if (score >= 80) {
            grade = 'B';
            if (score >= 89.5) {
                feedback = "Almost an A! Great effort.";
            } else {
                feedback = "Good job!";
            }
        } else if (score >= 70) {
            grade = 'C';
            if (score >= 79.5) {
                feedback = "Almost a B! Keep trying.";
            } else {
                feedback = "You passed.";
            }
        } else if (score >= 60) {
            grade = 'D';
            if (score >= 69.5) {
                feedback = "Almost a C! You can do it.";
            } else {
                feedback = "Needs improvement.";
            }
        } else {
            grade = 'F';
            feedback = "Failed. Better luck next time.";
        }

        cout << "Grade: " << grade << " - " << feedback << endl;

        // Ask if the user wants to perform another calculation
        cout << "Do you want to enter another score? (y/n): ";
        cin >> choice;

    } while (choice == 'y' || choice == 'Y');

    return 0;
}
