#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

int main()
{
    int choice;
    // Printing menu options
    cout << "Choose an operatioin:" << endl;
    cout<< "1. Calculate properties of a circle"<< endl;
    cout << "2. Convert temperature values"<< endl;
    cout<< "3. Check if a year is a leap year"<< endl;

    //Asking for user input
    cout<< "Enter your choice (1-3):" ;
    cin >> choice ;

    // Defining what will be executed according to the choice made
    switch (choice){
    // Choice one will calculate the properties of the circle
    case 1:{
        double radius;
        double circumference;
        double area;

        // Prompting user to input radius
        cout<< "Enter the radius (in cm) of the circle: ";
        cin>> radius;

        // Calculating properties
        circumference = 2*M_PI*radius;
        area = M_PI*radius*radius;

        //Setting output to 4 decimal places
        cout <<fixed<< setprecision(4);
        cout<< setw(20)<<"Circumference: "<<circumference<< "cm"<<endl;
        cout<<setw(20)<<"Area: "<<area<< "cm�"<< endl;
        break;
    }
    // Choice two will convert temperature values
    case 2:{
        double temperature;
        int descision;

        //Asking user to input the temperature to convert
        cout<<"Enter the temperature value: ";
        cin>>temperature;

        // Asking user what conversion they want to do while providing options
        cout<<"Choose the unit to convert to: " << endl;
        cout<<"1. Celsius to Fahrenheit"<< endl;
        cout<<"2. Fahrenheit to Celsius"<< endl;

        // Asking for user input
        cout<<"Enter your choice (1-2):";
        cin>> descision;

        switch(descision){
            //Converting C to F
            case 1:{
                double Fahrenheit = (9/5)* temperature + 32;
                cout<< temperature<<"C is "<< Fahrenheit<<"F"<<endl;
                break;
            }
            //Converting F to C
            case 2:{
                double Celsius = (temperature -32)*5.0/9.0;
                cout<< temperature<<"F is "<< Celsius<<"C"<<endl;
                break;
            }

            // Error handling
            default:
                cout<<"Invalid choice. Please select 1 or 2."<<endl;
                break;

        }
        break;
    }

    //Case 3; calculating whether its a leap year
    case 3: {
        int year;
        cout << "Enter a year: ";
        cin >> year;

        // Determining if the year entered is a leap year
        if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
            cout << year << " is a leap year." << endl;
        } else {
            cout << year << " is not a leap year." << endl;
        }
        break;}

    // Default
     default:
                cout<<"Invalid choice. Please select 1-3."<<endl;
                break;

    }
    return 0 ;

}

