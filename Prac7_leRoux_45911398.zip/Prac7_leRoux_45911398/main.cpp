#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

struct Person // tag = Person
{
    string idNumber; // Member of tag Person
    string gender;   // Member of tag Person
    int age;         // Member of tag Person
};

int calculateAge(string idNumber)
{
    const int currentYear = 2024;
    int century;
    string birthYear = idNumber.substr(0, 2); // Extract the first two digits

    // Determine the century based on birthYear
    if (stoi(birthYear) < 24)
    {
        century = 2000;
    }
    else
    {
        century = 1900;
    }

    int birthYearInt = century + stoi(birthYear);
    return currentYear - birthYearInt;
}

string determineGender(string idNumber)
{
    int genderDigit = idNumber[6] - '0';
    if (genderDigit < 5)
    {
        return "female";
    }
    else if (genderDigit <= 9)
    {
        return "male";
    }
    else
    {
        return "Invalid";
    }
}

void display(Person persons[], int size)
{
    // layout of display
    cout << setw(15) << "ID Number" << setw(10) << "Age" << setw(10) << "Gender" << endl;
    cout << "---------------------------------------------" << endl;
    for (int i = 0; i < size; i++)
    {
        cout << setw(15) << persons[i].idNumber
             << setw(10) << persons[i].age
             << setw(10) << persons[i].gender << endl;
    }
}

int main()
{
    Person persons[5];
    bool validID = true;

    for (int i = 0; i < 5; i++)
    {
        // Starting do-while loop to ensure that the ID number is the correct length
        do
        {
            // Prompting user to enter the ID number
            cout << "Enter the ID number for person " << i + 1 << " (13 digits): ";
            getline(cin, persons[i].idNumber);

            // Check whether the ID has 13 characters
            if (persons[i].idNumber.length() == 13)
            {
                validID = true;
            }
            else
            {
                validID = false;
                // Error message if ID length is not 13
                cout << "Please enter a valid ID with 13 characters!" << endl;
            }
        } while (validID == false);

        // Adding calculated age and determined gender to the struct's members
        persons[i].age = calculateAge(persons[i].idNumber);
        persons[i].gender = determineGender(persons[i].idNumber);
    }

    // Calling display function after all IDs have been entered
    display(persons, 5);

    return 0;
}
