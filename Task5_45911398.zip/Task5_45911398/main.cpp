#include <iostream>
#include <iomanip>

using namespace std;

// Declaration of attendee structure
struct Attendee {
    string name;
    bool swDevCareer;
    bool dbMgtCareer;
};

// Declaration of set registration function
void setRegistration(string arrAttendees[], bool arrSwDevCareer[], bool arrDbMgtCareer[], int SIZE) {
    int input;
    for (int i = 0; i < SIZE; i++) {  // Loop through each attendee
        // Ask about Software Development session
        do {
            cout << "Attendee " << arrAttendees[i] << ": Will you attend the Software Development Career Coaching Session? (1-Yes, 2-No): ";
            cin >> input;

            if (input == 1) {
                arrSwDevCareer[i] = true;
            } else if (input == 2) {
                arrSwDevCareer[i] = false;
            } else {
                cout << "Invalid input. Please enter 1 for Yes or 2 for No." << endl;
            }
        } while (input != 1 && input != 2);  // Validate input to be either 1 or 2

        // Ask about Database Management session
        do {
            cout << "Attendee " << arrAttendees[i] << ": Will you attend the Database Management Career Coaching Session? (1-Yes, 2-No): ";
            cin >> input;

            if (input == 1) {
                arrDbMgtCareer[i] = true;
            } else if (input == 2) {
                arrDbMgtCareer[i] = false;
            } else {
                cout << "Invalid input. Please enter 1 for Yes or 2 for No." << endl;
            }
        } while (input != 1 && input != 2);  // Validate input to be either 1 or 2
    }
}

// Declaration of display function
void displayAttendees(string arrAttendees[], bool arrSwDevCareer[], bool arrDbMgtCareer[], int SIZE) {
    cout << left << setw(5) << "---" << setw(25) << "============="
         << setw(35) << "Software Development"
         << setw(35) << "Database Management" << endl;
    cout << left << setw(5) << "No." << setw(25) << "Attendee Name"
         << setw(35) << "Software Development"
         << setw(35) << "Database Management" << endl;

    cout << left << setw(5) << "---" << setw(25) << "============="
         << setw(35) << "======================"
         << setw(35) << "======================" << endl;

    // Output of attendees
    for (int i = 0; i < SIZE; i++) {
        cout << left << setw(5) << i + 1 << setw(25) << arrAttendees[i];
        cout << setw(35) << (arrSwDevCareer[i] ? "true" : "false");
        cout << setw(35) << (arrDbMgtCareer[i] ? "true" : "false");
        cout << endl;
    }
}

// Declaration of ComputeAttendeeCount
int ComputeAttendeeCount(bool arrSwDevCareer[], bool arrDbMgtCareer[], int SIZE) {
    int count = 0;
    for (int i = 0; i < SIZE; i++) {
        if (arrSwDevCareer[i] || arrDbMgtCareer[i]) {
            count++;
        }
    }
    return count;
}

int main() {
    const int SIZE = 10;

    string arrAttendees[] = {"Lefu Nkosi", "James Jack", "Kefiwe Nkosi", "Josh Mark", "Tom Jakes",
                             "Brendon Smith", "Zanile Mabaso", "Paul Kruger", "Jude Chris", "Thuli Molefe"};

    bool arrSwDevCareer[SIZE] = {false};  // Initialize all elements to false
    bool arrDbMgtCareer[SIZE] = {false};  // Initialize all elements to false

    // Set registration for both sessions for each attendee
    setRegistration(arrAttendees, arrSwDevCareer, arrDbMgtCareer, SIZE);

    // Display attendee list and session registration status after initial registration
    cout << "\nList of Attendees and their Session Registration Status:" << endl;
    displayAttendees(arrAttendees, arrSwDevCareer, arrDbMgtCareer, SIZE);

    // Compute and display the total number of attendees after the initial registration
    int totalAttendees = ComputeAttendeeCount(arrSwDevCareer, arrDbMgtCareer, SIZE);
    cout << "\nTotal number of attendees for the career coaching sessions: " << totalAttendees << endl;

    // Ask if the user wants to update any attendance status
    char updateChoice;
    int attendeeNumber, sessionChoice, changeChoice;
    cout << "\nDo you want to change the attendance status of an attendee (Y-yes / N-no): ";
    cin >> updateChoice;

    if (updateChoice == 'Y' || updateChoice == 'y') {
        do {
            // Ask which attendee to update
            cout << "Which attendee do you want to update? ";
            cin >> attendeeNumber;

            if (attendeeNumber > 0 && attendeeNumber <= SIZE) {
                // Ask which session to update
                cout << "Which coaching session do you want to update? (1-Software Development / 2-Database Management): ";
                cin >> sessionChoice;

                // Ask for the change (1 for accept, 2 for decline)
                cout << "Indicate the change (1-accept / 2-decline): ";
                cin >> changeChoice;

                if (sessionChoice == 1) {
                    arrSwDevCareer[attendeeNumber - 1] = (changeChoice == 1);
                } else if (sessionChoice == 2) {
                    arrDbMgtCareer[attendeeNumber - 1] = (changeChoice == 1);
                } else {
                    cout << "Invalid session choice." << endl;
                }
            } else {
                cout << "Invalid attendee number." << endl;
            }

            // Ask if the user wants to update another attendee
            cout << "\nDo you want to change another status? (Y-yes / N-no): ";
            cin >> updateChoice;

        } while (updateChoice == 'Y' || updateChoice == 'y');

        // If updates were made, display the updated attendee list and session registration status
        cout << "\nUpdated List of Attendees and their Session Registration Status:" << endl;
        displayAttendees(arrAttendees, arrSwDevCareer, arrDbMgtCareer, SIZE);

        // Compute and display the updated total number of attendees
        totalAttendees = ComputeAttendeeCount(arrSwDevCareer, arrDbMgtCareer, SIZE);
        cout << "\nTotal number of attendees for the career coaching sessions: " << totalAttendees << endl;
    }

    return 0;
}
