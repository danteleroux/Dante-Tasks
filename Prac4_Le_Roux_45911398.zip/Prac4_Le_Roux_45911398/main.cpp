// Le Roux 45911398
#include <iostream>
#include <iomanip>
using namespace std;
//Declaring the 2 user defined functions
void printRow(int rowNum, int tableSize);
void printTable(int num);


int main() {
    int num;
    // Prompting user to input size of table
    cout << "Enter the size of the multiplication table: ";
    cin >> num;
    // Call the table printing function
    printTable(num);
    return 0;
}

// Row printing function
void printRow(int rowNum, int tableSize) {
    for (int i = 1; i <= tableSize; i++) {
        // Print product of rowNum and i
        cout << fixed << setw(10) << rowNum * i;
    }
    cout << endl;
}

// Table printing function
void printTable(int num) {
    for (int i = 1; i <= num; i++) {
        // Call printRow
        printRow(i, num);
    }
    cout << endl;
}
