// Dante le Roux 45911398
#include <iostream>
#include <string>
#include <cctype>

using namespace std;

int main()
{
    // declaration of bool
    bool flag = true;

    // declaration of name variable
    string name;

    // declaration of array
    string names_array[20];
    int counter = 0; // Initialize counter to 0

    // declaration of letter
    char letter ;


    // starting do-while
    do {
        cout << "Enter name (X to quit input): ";
        cin >> name;

        // If statement to check if name is an X and the counter is less than 20
        if (name == "X" || name == "x"|| counter>= 20) {
            flag = false;
        }
        // Adding name to list
        else {
            names_array[counter] = name;
            counter += 1;  // Increment counter
        }
    }
    while (flag );


    //Title of the list
    cout << "List of names" << endl;

    //empty line
    cout << endl;

    // For loop to output names
    for (int i = 0; i < counter; i++) {
        cout << names_array[i] << endl;  // Output each name from the array
    }

    //Writing code to request user to input a letter
    cout<< endl;
    cout<< "Enter a letter: ";
    cin>> letter;
    // String
    cout<<"Names starting with the "<<letter<<endl;

    // For loop to look for first letter that corresponds with first letter entered
     for (int i = 0; i < counter; i++) {
        if (toupper(names_array[i][0]) == toupper(letter)) {
            cout << names_array[i] << endl;
        }
    }

    return 0;
}
