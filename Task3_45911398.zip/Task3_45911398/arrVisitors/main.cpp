//Dante le Roux 45911398
#include <iostream>

using namespace std;

int main()
{
    // Declaration of array
    int arrVisitors[6];

    // Declaration of variables
    int visitors;
    int minVisitor, maxVisitor;
    int minDay = 1, maxDay = 1, total = 0;

    // For loop to ensure it doesn't go above 6
    for (int i = 0; i <= 5; i++) {
        cout << "Enter the number of visitors on day " << i + 1 << ": ";
        // Adding the visitors to the array
        cin >> arrVisitors[i];

        // Sum of total amount of visitors
        total += arrVisitors[i];
    }

    cout << "" << endl;

    // Printing the amount of visitors per day
    cout << "List of visitors per day: " << endl;

    // For loop to output amount of visitors
    for (int j = 0; j <= 5; j++) {
        cout << "Day " << j + 1 << ": " << arrVisitors[j] << endl;
    }
    cout << "" << endl;

    // Assignment of min and max variables
    minVisitor = arrVisitors[0];
    maxVisitor = arrVisitors[0];

    // Least number of visitors
    for (int k = 1; k <= 5; k++) {
        // If statement to find the least number of visitors
        if (arrVisitors[k] < minVisitor) {
            minVisitor = arrVisitors[k];
            minDay = k + 1;
        }

        // If statement to find the most number of visitors
        if (arrVisitors[k] > maxVisitor) {
            maxVisitor = arrVisitors[k];
            maxDay = k + 1;
        }
    }

    // Output of max, min and total
    cout << "Day with the least number of visitors is day " << minDay << " with " << minVisitor << " visitors" << endl;
    cout << "Day with the most number of visitors is day " << maxDay << " with " << maxVisitor << " visitors" << endl;
    cout<<"The total amount of visitors is: " << total;


    return 0;
}
