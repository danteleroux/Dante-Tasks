#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main()
{
    // Declaring grade variables
    int mathGrade, scienceGrade, englishGrade;


    cout << "**Grading System**" <<  endl;
    cout << "Enter your Math grade: " ;
    cin >> mathGrade;
    cout << "Enter your Science grade: " ;
    cin >> scienceGrade;
    cout << "Enter your English grade: ";
    cin >> englishGrade;
    // Print an empty line
    cout << endl;

    // Declaring details

    int total = mathGrade + scienceGrade + englishGrade;
    double averageGrade = total / 3.0;
    char grade;

    // Finding grade
    if(averageGrade >= 90)
        grade = 'A';
    else if(averageGrade >= 80)
        grade = 'B';
    else if(averageGrade >= 70)
        grade = 'C';
    else if(averageGrade >= 60)
        grade = 'D';
    else
        grade = 'F';


    // Printing the details results
    cout<<"**Details**"<< endl;
    cout << fixed << setprecision(2);
    cout<< "Average grade is: "<<averageGrade<< endl;
    cout<<"Result: "<< grade<< endl;
    // Print an empty line
    cout << endl;

    // Declaring results
    int roundedAverage = round(averageGrade);
    bool isPassed = (roundedAverage >= 60);
    string customMessage;

    if (isPassed)
        customMessage = "Congratulations! You have passed.";
    else
        customMessage = "Unfortunately, you have failed. Better luck next time!";

    //Printing results
    cout << "**Result**" << endl;
    cout<< "Rounded average: "<< roundedAverage << endl;
    cout<< "Result: "<< customMessage << endl;
    // Print an empty line
    cout << endl;



    return 0;
}
