#include <iostream>

using namespace std;

int main()
{
    char again;

    do{
        // Printing menu
        cout << "Menu" << endl;
        cout << "1. Addition (+)" << endl;
        cout << "2. Subraction (-)" << endl;
        cout << "3. Multiplication (*)" << endl;
        cout << "4. Division (/)" << endl;

        // defining choice
        int choice;


        // Prompting user for input choice
        cout<< "Choose an operation (1-4):";
        // Receiving input choice
        cin >> choice;

        if (choice == 1 || choice == 2 || choice == 3 || choice == 4){
                // defining numbers
            int num1, num2;

            // Prompting user to enter two numbers
            cout << "Enter the first number:  " ;
            // Receiving input from user
            cin >> num1 ;
            cout << "Enter the second number:  " ;
            cin  >> num2;

            int result;

            // Starting if statements
            switch (choice ){
                case 1: // if 1 curly brace
                result = num1 + num2;
                cout << "Result of Addition: "<< result<< endl;
                break;

                case 2:
                result = num1 - num2;
                cout << "Result of Subraction: "<< result<< endl;
                break;

                case 3:
                result = num1 * num2;
                cout << "Result of Multiplication: "<< (num1 * num2)<< endl;
                break;

                case 4:
                // error handling. Num2 cannot be 0!
                    if (num2 != 0){
                        double result = static_cast<double>(num1)/(num2);

                        cout << "Result of division: "<< result<< endl;
                    }
                    else {
                        cout<<"ERROR! Number not divisible by 0!"<< endl;
                    }
                    break;

                default:
                    cout<< "invalid choice" << endl;
                    break;

                }
            }
        else{
            cout<<"Invalid choice. Please select a number between 1 and 4."<<endl;
            }
            cout<<"Do you want to perform another calculation? (y/n): ";
            cin>>again;
    }while(again =='y' || again == 'Y');

    return 0;
}
