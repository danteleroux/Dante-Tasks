#include <iostream>
#include <cstdlib>  // For srand() and rand()
#include <ctime>    // For time()
#include <fstream>  // For file handling
using namespace std;

void adoptionSummary(int count, float totalFees, const string &adoptionDetails)
{
    ofstream myFile;
    myFile.open("AdoptionAnimals.txt");

    if (myFile.is_open())
    {
        myFile << adoptionDetails;

        myFile << "Summary:" << endl;
        myFile << "The total pets adopted: " << count << "." << endl;
        myFile << "Total adoption fees collected: R" << totalFees << endl;

        myFile.close();
    }
}

int main()
{
    // Seed the random number generator ONCE at the start of the program
    srand(time(0));

    // Declaring variables
    string animal;
    string adoptionDetails = "";
    char repeat;
    int price = 0;  // Changed price to an integer to avoid decimals
    int totalFees = 0;  // Changed totalFees to an integer to avoid decimals
    int count = 0;

    do {
        // Generate a random integer between 50 and 150
        int randomNum = rand() % 101 + 50;  // Generates an integer between 50 and 150

        char choice;

        cout << "Please choose a pet to adopt (D=dog, C=cat, R=rabbit): ";
        cin >> choice;

        // Input validation
        while (choice != 'D' && choice != 'C' && choice != 'R' && choice != 'd' && choice != 'c' && choice != 'r')
        {
            cout << "Please choose a valid pet type to adopt!" << endl;
            cout << "Please choose a pet to adopt (D=dog, C=cat, R=rabbit): ";
            cin >> choice;
        }

        // Determine the animal type and set the price
        if (choice == 'D' || choice == 'd')
        {
            animal = "dog";
            price = randomNum;
        }
        else if (choice == 'C' || choice == 'c')
        {
            animal = "cat";
            price = randomNum;
        }
        else if (choice == 'R' || choice == 'r')
        {
            animal = "rabbit";
            price = randomNum;
        }

        // Add details to the adoption details string
        adoptionDetails += "The adoption fee for the " + animal + " is R" + to_string(price) + ".\n";

        cout << "The adoption fee for a " << animal << " is R" << price << endl;
        cout << "Would you like to adopt another pet? (y/n): ";
        cin >> repeat;

        // Update count and total fees
        count += 1;
        totalFees += price;

    } while (repeat == 'y' || repeat == 'Y');

    // Call the function to save the summary to a file
    adoptionSummary(count, totalFees, adoptionDetails);

    return 0;
}
